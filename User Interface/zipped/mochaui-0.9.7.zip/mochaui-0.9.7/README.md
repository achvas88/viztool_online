# MochaUI

A MooTools UI Library User Interface Library

Development Source
/src - all source files required to build

Generated Files
/demo - working demo (all files needed to host)
/build - compressed/minimized MochaUI

Latest release is 0.9.7

