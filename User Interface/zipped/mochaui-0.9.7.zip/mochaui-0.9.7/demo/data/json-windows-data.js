{"windows":[

	{
		"id": "json01",
		"addClass": "jsonExample",
		"title":"Window Created with Json Data",
		"content":"First window",
		"maximizable": false,
		"resizable": false,
		"x": 250,
		"y": 135
	},
	{
		"id": "json02",
		"addClass": "jsonExample",		
		"title":"Another Window Created with Json",
		"content":"Second window",
		"maximizable": false,
		"resizable": false,	
		"x": 310,
		"y": 210
	},
	{
		"id": "json03",
		"addClass": "jsonExample",		
		"title":"And Another ...",
		"content":"Third",
		"maximizable": false,
		"resizable": false,		
		"x": 370,
		"y": 285
	}

]}